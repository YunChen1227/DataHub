package com.ect.api_demo.common;

import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;

/*
 * HTTP 工具类
 */
public class HttpUtil {
	/**
	 * 设置请求超时时常
	 * 
	 * @return
	 */
	private static RequestConfig getConfig() {
		int timeout = 30000;
		return RequestConfig.custom().setConnectTimeout(timeout).setSocketTimeout(timeout).build();
	}

	/**
	 * 创建单向ssl的连接
	 * 
	 * @return
	 * @throws AppException
	 */
	private static CloseableHttpClient getSingleSSLConnection() {
		CloseableHttpClient httpClient = null;
		try {
			SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
				public boolean isTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString)
						throws CertificateException {
					return true;
				}
			}).build();
			SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, new HostnameVerifier() {

				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			});
			httpClient = HttpClients.custom().setSSLSocketFactory(sslsf).setDefaultRequestConfig(getConfig()).build();
			return httpClient;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String sendMapByPost(Map<String, String> paramMap, String url) throws Exception {
		CloseableHttpResponse response = null;
		try {
			HttpPost httpPost = new HttpPost(url);
			// 创建参数队列
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			for (String key : paramMap.keySet()) {
				nameValuePairs.add(new BasicNameValuePair(key, paramMap.get(key)));
			}
			try {
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));
			} catch (Exception e) {
				e.printStackTrace();
			}
			CloseableHttpClient httpClient = getSingleSSLConnection();
			response = httpClient.execute(httpPost);
			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode != 200) {
				httpPost.abort();
			}
			HttpEntity entity = response.getEntity();
			String result = null;
			if (entity != null) {
				result = EntityUtils.toString(entity, "utf-8");
			} else {
				throw new Exception("返回结果为空!");
			}
			EntityUtils.consume(entity);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (response != null)
				try {
					response.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		return null;
	}
}
