package com.ect.api_demo.common;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;

/*
 * 签名算法类
 */
public class SignedRequestsHelper {
	// 字符集格式
	private static final String UTF8_CHARSET = "UTF-8";
	// 加密算法
	private static final String HMAC_SHA256_ALGORITHM = "HmacSHA256";
	// SK
	private String secretAccessKey = "secretAccessKey";

	private SecretKeySpec secretKeySpec = null;
	private Mac mac = null;

	private void updateMac() throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
		byte[] secretyKeyBytes = Base64.decodeBase64(secretAccessKey);
		secretKeySpec = new SecretKeySpec(secretyKeyBytes, HMAC_SHA256_ALGORITHM);
		mac = Mac.getInstance(HMAC_SHA256_ALGORITHM);
		mac.init(secretKeySpec);
	}

	public String hmac(String stringToSign) {
		String signature = null;
		byte[] data;
		byte[] rawHmac;
		try {
			data = stringToSign.getBytes(UTF8_CHARSET);
			rawHmac = mac.doFinal(data);
			Base64 encoder = new Base64();
			signature = new String(encoder.encode(rawHmac));
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(UTF8_CHARSET + " is unsupported!", e);
		}
		return signature;
	}

	private String percentEncodeRfc3986(String s) {
		String out;
		try {
			out = URLEncoder.encode(s, UTF8_CHARSET);
		} catch (UnsupportedEncodingException e) {
			out = s;
		}
		return out;
	}

	public String sign(SignatureMessage message) {

		String toSign = message.getHttpMethod() + "\n" + message.getEndpoint() + "\n" + message.getRequestUri() + "\n"
				+ message.getVersion() + "\n" + message.getMsgId() + "\n" + message.getOrgCode() + "\n"
				+ message.getAccessKeyId() + "\n" + message.getTimestamp() + "\n" + message.getArgs();
		String hmac = hmac(toSign);
		String sig = percentEncodeRfc3986(hmac);
		return sig;
	}

	public void setSecretAccessKey(String _secretAccessKey)
			throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
		secretAccessKey = _secretAccessKey;
		updateMac();
	}
}
