package com.ect.api_demo;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;

import com.ect.api_demo.common.HttpUtil;
import com.ect.api_demo.common.SignatureMessage;
import com.ect.api_demo.common.SignedRequestsHelper;

/*
 * 一共有两种请求方式
 * 1、异步请求方式
 * 异步请求分两步，第一步Apply，第二步Result。两步的requestUri会不一样，不同产品的requestUri也会不一样。具体需要查阅接口说明。
 * 2、同步请求方式
 * 同步请求只有一步，不同产品的requestUri会不一样。具体需要查阅接口说明。
 */

public class Main {
	public static void main(String[] args) throws Exception {
		// 版本号，默认为1.0
		String version = "1.0";
		// prodCode 产品代码
		String prodCode = "所请求产品的产品代码";
		// orgCode 机构代码
		String orgCode = "所在机构的机构代码";
		// accessKeyId 访问的Key
		String accessKeyId = "所在机构的AK";
		// 加签用的Key
		String secretAccessKey = "所在机构的SK";
		// 请求的域名或者IP
		// 生产环境都是 https://cisp.zenitera.com
		// 测试环境都是 https://cispuat.tongtongcf.com
		String endpoint = "请求的域名或者IP";
		// requestUri 请求路径 Uri
		// 不同产品的请求路径略有不同，具体请查阅接口说明
		String requestUri = "请求路径Uri";// 请求路径
		// 时间戳
		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		// msgId
		String msgId = orgCode + timeStamp;
		// queryMode，一般为0
		String queryMode = "0";

		// 请求用的业务相关参数
		String businessArgs = null;
		// 签名
		String signature = null;

		// 1.设置查询案例输入
		// 请求用的业务相关参数的Map
		// 一般在Result的时候，只有一个参数 argsMap.put("orderNo", "通过Apply得到的订单号");
		Map<String, String> argsMap = new HashMap<String, String>();
		argsMap.put("prodCode", prodCode);
		argsMap.put("其他业务参数", "");// 要查询的关键字

		// 2.将查询条件转换为json串
		ObjectMapper objmapper = new ObjectMapper();
		businessArgs = objmapper.writeValueAsString(argsMap);

		// 3.加签
		SignatureMessage signMessage = new SignatureMessage();
		signMessage.setEndpoint(endpoint);
		signMessage.setRequestUri(requestUri);
		signMessage.setHttpMethod("POST");
		signMessage.setAccessKeyId(accessKeyId);
		signMessage.setMsgId(msgId);
		signMessage.setOrgCode(orgCode);
		signMessage.setVersion(version);
		signMessage.setTimestamp(timeStamp);
		signMessage.setArgs(businessArgs);
		
		SignedRequestsHelper signHerlper = new SignedRequestsHelper();
		signHerlper.setSecretAccessKey(secretAccessKey);
		signature = signHerlper.sign(signMessage);

		// 4.设置报文信息
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("version", version);
		paramMap.put("msgId", msgId);
		paramMap.put("orgCode", orgCode);
		paramMap.put("accessKeyId", accessKeyId);
		paramMap.put("transTime", new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()));
		paramMap.put("timestamp", timeStamp);
		// 特别注意，只在设置报文信息的时候，对businessArgs进行URLEncode，在计算签名的时候，不进行
		paramMap.put("args", URLEncoder.encode(businessArgs,"UTF-8"));
		paramMap.put("signature", signature);// 加签结果
		paramMap.put("queryMode", queryMode);

		// 5.发送报文
		String result = HttpUtil.sendMapByPost(paramMap, endpoint + requestUri);

		System.out.println(result);
	}
}
